<?php
require('db.php');
$id=$_REQUEST['id'];
$query = "DELETE FROM CreativeLearner WHERE Student_ID=$Student_ID";
$result = mysqli_query($con,$query) or die ( mysqli_error());
header("Location: view.php");
?>
