<?php
$CreativeLearner = range(11,20);
shuffle($CreativeLearner);
for ($x=0; $x< 10; $x++)
{
echo $CreativeLearner[$x].' ';
}
echo "\n"
?>
