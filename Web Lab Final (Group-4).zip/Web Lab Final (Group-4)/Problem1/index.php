<?php
include_once 'database.php';
if(isset($_POST['save']))
{
	 $name = $_POST['Student_Name'];
	 $id = $_POST['Student_ID'];
	 $age = $_POST['Student_age'];
	 $username = $_POST['Student_username'];
   $password = $_POST['Password'];
	 $sql = "INSERT INTO CreativeLearner (Student_Name,Student_ID,Student_age,Student_username,Password)
	 VALUES ('$name','$id','$age','$username','$password')";
	 if (mysqli_query($conn, $sql)) {
		echo "Data insertion successfull !";
	 } else {
		echo "Data insertion is not successfull" . $sql . "
" . mysqli_error($conn);
	 }
	 mysqli_close($conn);
}
?>
