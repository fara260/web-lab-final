<?php
$servername='localhost';
$username='root';
$password='';
$dbname = "diu";
$conn=mysqli_connect($servername,$username,$password,$diu);
if(!$conn){
   die('Could not Connect My Sql:' .mysql_error());
}
?>
