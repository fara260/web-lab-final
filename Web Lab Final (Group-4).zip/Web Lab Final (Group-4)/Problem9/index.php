<?php
for($creativelearner=1;$creativelearner<=5;$creativelearner++)
{
   for ($learner=1;$learner<=$creativelearner;$learner++)
    {
	 echo "*";
	    if($learner< $creativelearner)
		 {
		   echo " ";
		 }
     }
 echo "\n";
}
?>
